<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8"/>
  <title>Primeiro Exemplo PHP</title>
  <style>
      h2 {
        color: #80a2ff;
        text-shadow: 1px 1px 1px black;
      }
  </style>
</head>
<body>
    <h1>Testando PHP</h1>
    <?php
        echo "<h2>Ola, <br/> Mundo!</h2>";
    ?>
</body>
</html>
 