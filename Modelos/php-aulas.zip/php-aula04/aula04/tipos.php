<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8"/>
  <link rel="stylesheet" href="_css/estilo.css"/>
  <title></title>
</head>
<body>
<div>
    <?php
       $nome = "Maria";
       $idade = 18;
       echo "$nome tem $idade anos!";
    ?>
</div>
</body>
</html>